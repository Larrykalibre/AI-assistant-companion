export type TrackingState = {
    x: number;
    y: number;
    deltaX: number;
    deltaY: number;
    speed: number;
};

export class Tracker {
    private currentPosition = { x: 0, y: 0 };
    private previousPosition = { x: 0, y: 0 };
    private previousTimestamp = Date.now();

    trackMovement(newPosition: { x: number; y: number }): TrackingState {
        const now = Date.now();
        const deltaTime = Math.max(1, now - this.previousTimestamp) / 1000;
        const deltaX = newPosition.x - this.previousPosition.x;
        const deltaY = newPosition.y - this.previousPosition.y;
        const distance = Math.hypot(deltaX, deltaY);
        const speed = distance / deltaTime;

        this.previousPosition = { ...newPosition };
        this.previousTimestamp = now;
        this.currentPosition = { ...newPosition };

        return {
            x: newPosition.x,
            y: newPosition.y,
            deltaX,
            deltaY,
            speed,
        };
    }

    getCurrentPosition(): { x: number; y: number } {
        return { ...this.currentPosition };
    }
}
