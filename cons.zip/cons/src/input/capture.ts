import { EventEmitter } from 'events';

export type CaptureFrame = {
    pointer: { x: number; y: number };
    target: { x: number; y: number };
    timestamp: number;
};

export class Capture extends EventEmitter {
    private isCapturing: boolean;
    private lastFrame: CaptureFrame | null;

    constructor() {
        super();
        this.isCapturing = false;
        this.lastFrame = null;
    }

    startCapture(): void {
        if (this.isCapturing) {
            return;
        }

        this.isCapturing = true;
        console.log('Capture adapter armed. Awaiting external detector frames.');
    }

    stopCapture(): void {
        if (!this.isCapturing) {
            return;
        }

        this.isCapturing = false;
        this.lastFrame = null;
        console.log('Capture adapter stopped.');
    }

    onData(callback: (frame: CaptureFrame) => void): void {
        this.on('frame', callback);
    }
    ingestExternalFrame(frame: CaptureFrame): void {
        if (!this.isCapturing) {
            return;
        }
        this.lastFrame = frame;
        this.emit('frame', frame);
    }
}
