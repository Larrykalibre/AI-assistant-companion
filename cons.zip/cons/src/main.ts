/*
  assistant-only mode:
  This Electron app UI is driven by the external detector subprocess launched in electron-main.js.

  The previous simulated pipeline (Capture/Tracker/Model/Renderer) is intentionally disabled so it cannot
  interfere with end-to-end runtime verification.
*/

// eslint-disable-next-line @typescript-eslint/no-unused-vars
const DISABLED_SIMULATED_PIPELINE = true;

if (DISABLED_SIMULATED_PIPELINE) {
  console.log('[src/main.ts] Simulated pipeline disabled. Waiting for IPC from external detector.');
}

