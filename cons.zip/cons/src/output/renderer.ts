import type { InferenceOutput } from '../ai/model';
import type { TrackingState } from '../input/tracker';

export class Renderer {
    renderOutput(_results: InferenceOutput, _state: TrackingState): never {
        throw new Error(
            'Legacy TypeScript renderer is disabled. Render detector.py frames through ui/app.js in the Electron renderer.',
        );
    }
}
