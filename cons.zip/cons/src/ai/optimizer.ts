import type { Model } from './model';

export class Optimizer {
    optimize(_model: Model, _confidence: number): never {
        throw new Error(
            'Legacy optimizer is disabled. Runtime optimization must be derived from detector.py telemetry and renderer coaching metrics.',
        );
    }

    evaluate(_model: Model, _testData: Array<{ input: unknown; expected: unknown }>): never {
        throw new Error('Legacy optimizer evaluation is disabled in detector-first runtime mode.');
    }
}
