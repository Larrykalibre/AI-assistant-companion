import type { InferenceInput, InferenceOutput } from './model';

export function runInference(
    _inputData: InferenceInput,
    _model: { predict(inputData: InferenceInput): InferenceOutput },
): never {
    throw new Error(
        'Legacy TypeScript inference pipeline is disabled. Use detector.py JSON frames from electron-main.js as the runtime source of truth.',
    );
}
