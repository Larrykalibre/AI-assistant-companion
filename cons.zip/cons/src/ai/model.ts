export type InferenceInput = {
    targetX: number;
    targetY: number;
    pointerX: number;
    pointerY: number;
    deltaX: number;
    deltaY: number;
    speed: number;
};

export type InferenceOutput = {
    aimCorrection: { x: number; y: number };
    confidence: number;
    recommendedSpeed: number;
};

type ModelParameters = {
    sensitivity: number;
    smoothing: number;
    baselineConfidence: number;
};

export class Model {
    private parameters: ModelParameters;

    constructor() {
        this.parameters = {
            sensitivity: 0.85,
            smoothing: 0.12,
            baselineConfidence: 0.75,
        };
    }

    async loadModel(modelPath?: string): Promise<void> {
        console.log(
            `Legacy model adapter disabled${modelPath ? ` (${modelPath})` : ''}. detector.py is the active model runtime.`,
        );
    }

    predict(_inputData: InferenceInput): InferenceOutput {
        throw new Error(
            'Legacy TypeScript model predict() is disabled. Consume detector.py output payloads in the Electron renderer.',
        );
    }

    getParameters(): ModelParameters {
        return { ...this.parameters };
    }

    updateParameters(updates: Partial<ModelParameters>): void {
        this.parameters = { ...this.parameters, ...updates };
    }
}
