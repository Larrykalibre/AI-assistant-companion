const { contextBridge, ipcRenderer } = require('electron');

function safeSend(channel, payload) {
    try {
        ipcRenderer.send(channel, payload);
    } catch (error) {
        console.error(`[preload] failed to send ${channel}`, error);
    }
}

function subscribe(channel, callback) {
    if (typeof callback !== 'function') {
        return () => {};
    }
    const wrapped = (_, data) => {
        try {
            callback(data);
        } catch (error) {
            console.error(`[preload] callback failed for ${channel}`, error);
        }
    };
    ipcRenderer.on(channel, wrapped);
    return () => ipcRenderer.removeListener(channel, wrapped);
}

window.addEventListener('DOMContentLoaded', () => {
    safeSend('renderer-ready', { ts: Date.now() });
});

contextBridge.exposeInMainWorld('api', {
    toggleAssistant: (isRunning = false) => safeSend('toggle-assistant', Boolean(isRunning)),
    updateSettings: (settings = {}) => safeSend('update-settings', settings),
    onAssistantFrame: (callback) => subscribe('assistant-frame', callback),
    onAssistantStatus: (callback) => subscribe('assistant-status', callback),
    onAssistantOutput: (callback) => subscribe('assistant-output', callback),
    onAssistantError: (callback) => subscribe('assistant-error', callback),
    onAssistantStarted: (callback) => subscribe('assistant-started', callback),
    onAssistantStopped: (callback) => subscribe('assistant-stopped', callback),
    onSettingsApplied: (callback) => subscribe('settings-applied', callback),
    onAssistantLog: (callback) => subscribe('assistant-log', callback),
    reportOverlayReady: () => safeSend('overlay-ready', { ts: Date.now() }),
});
