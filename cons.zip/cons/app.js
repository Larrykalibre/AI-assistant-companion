let isRunning = false;
let updateCount = 0;
let overlayWidth = 640;
let overlayHeight = 360;
let overlayReported = false;
let assistantOutputCount = 0;

const trails = new Map();
const canvas = document.getElementById('overlay-canvas');
const ctx = canvas ? canvas.getContext('2d') : null;

const overlayState = {
    enabled: true,
    opacity: 0.6,
    trailEnabled: true,
    trailLength: 30,
    boxColor: '#ffcc33',
    boxThickness: 2,
    boxGlow: true,
    trailColor: '#2affa0',
    trailOpacity: 0.5,
    trailThickness: 2,
    predictionStrength: 0.6,
    maxTargets: 12,
    showLabels: true,
    showIndicators: true,
    fontSize: 12,
    showFPS: true,
    overlayTransparency: 0.7,
    velocitySensitivity: 1.0,
};

const analysisState = {
    offsets: [],
    pointerDistances: [],
    pointerSpeeds: [],
    reactionSamples: [],
    overFlickEvents: 0,
    currentTargetId: null,
    reactionStartTs: null,
};

const dom = {
    startBtn: document.getElementById('start-btn'),
    aimbotToggle: document.getElementById('aimbot-toggle'),
    workingDot: document.getElementById('working-dot'),
    workingText: document.getElementById('working-text'),
    modelStatus: document.getElementById('model-status'),
    updatesPerSec: document.getElementById('updates-per-sec'),
    pointerPos: document.getElementById('pointer-pos'),
    velocity: document.getElementById('velocity'),
    confidence: document.getElementById('confidence'),
    aimCorrection: document.getElementById('aim-correction'),
    targetCount: document.getElementById('target-count'),
    detectionSource: document.getElementById('detection-source'),
    reactionTime: document.getElementById('reaction-time'),
    trackingAccuracy: document.getElementById('tracking-accuracy'),
    coachingPrimary: document.getElementById('coaching-primary'),
    coachingList: document.getElementById('coaching-list'),
    profilePlayerType: document.getElementById('profile-player-type'),
    profileReaction: document.getElementById('profile-reaction'),
    profileAccuracy: document.getElementById('profile-accuracy'),
    profileWeaknesses: document.getElementById('profile-weaknesses'),
};

const diagDom = {
    yolo: document.getElementById('diag-yolo'),
    capture: document.getElementById('diag-capture'),
    ipc: document.getElementById('diag-ipc'),
    renderer: document.getElementById('diag-renderer'),
    overlay: document.getElementById('diag-overlay'),
    online: document.getElementById('diag-online'),
    json: document.getElementById('diag-json'),
    detection: document.getElementById('diag-detection'),
    status: document.getElementById('diag-status'),
    coaching: document.getElementById('diag-coaching'),
};

function avg(values) {
    if (!values.length) {
        return 0;
    }
    return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function pushBounded(list, value, maxLength = 240) {
    list.push(value);
    while (list.length > maxLength) {
        list.shift();
    }
}

function safeText(element, text) {
    if (element) {
        element.textContent = text;
    }
}

function setDiagState(node, ok, warn = false) {
    if (!node) {
        return;
    }
    node.classList.remove('ok', 'warn');
    if (ok) {
        node.classList.add('ok');
        node.textContent = 'YES';
        return;
    }
    if (warn) {
        node.classList.add('warn');
        node.textContent = 'WARN';
        return;
    }
    node.textContent = 'NO';
}

function hexToRgba(hex, alpha = 1) {
    if (!hex || typeof hex !== 'string') {
        return `rgba(255,255,255,${alpha})`;
    }
    const cleaned = hex.replace('#', '');
    const bigint = parseInt(cleaned, 16);
    const r = (bigint >> 16) & 255;
    const g = (bigint >> 8) & 255;
    const b = bigint & 255;
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
}

function applyDiagnostics(diagnostics) {
    if (!diagnostics) {
        return;
    }
    setDiagState(diagDom.yolo, Boolean(diagnostics.yoloLoaded));
    setDiagState(diagDom.capture, Boolean(diagnostics.screenCaptureStarted));
    setDiagState(diagDom.ipc, Boolean(diagnostics.rendererConnected));
    setDiagState(diagDom.renderer, Boolean(diagnostics.rendererConnected));
    setDiagState(diagDom.overlay, Boolean(diagnostics.overlayReady));
    setDiagState(diagDom.online, Boolean(diagnostics.assistantOnline));
    setDiagState(diagDom.json, Boolean(diagnostics.jsonFramesEmit));
    setDiagState(diagDom.detection, Boolean(diagnostics.detectionRuns));
    setDiagState(diagDom.status, Boolean(diagnostics.statusFlow));
}

function resizeCanvas() {
    if (!canvas) {
        return;
    }
    const wrapper = canvas.parentElement;
    if (!wrapper) {
        return;
    }
    const rect = wrapper.getBoundingClientRect();
    canvas.width = Math.max(1, Math.floor(rect.width));
    canvas.height = Math.max(1, Math.floor(rect.height));

    if (!overlayReported && window.api?.reportOverlayReady) {
        window.api.reportOverlayReady();
        overlayReported = true;
        setDiagState(diagDom.overlay, true);
    }
}

function clearOverlay() {
    if (!ctx || !canvas) {
        return;
    }
    ctx.clearRect(0, 0, canvas.width, canvas.height);
}

function drawCrosshair() {
    if (!ctx || !canvas) {
        return;
    }
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(centerX - 18, centerY);
    ctx.lineTo(centerX + 18, centerY);
    ctx.moveTo(centerX, centerY - 18);
    ctx.lineTo(centerX, centerY + 18);
    ctx.stroke();
}

function drawNoDetectionState() {
    if (!ctx || !canvas) {
        return;
    }
    ctx.fillStyle = 'rgba(255, 255, 255, 0.86)';
    ctx.font = '18px monospace';
    ctx.fillText('No targets detected', 20, 32);
    ctx.fillStyle = 'rgba(255, 255, 255, 0.55)';
    ctx.font = '13px monospace';
    ctx.fillText('Waiting for frame objects…', 20, 54);
}

function resolvePointer(frame) {
    const raw = frame?.node_pointer || null;
    if (raw && Number.isFinite(raw.x) && Number.isFinite(raw.y)) {
        return {
            x: raw.x,
            y: raw.y,
            speed: Number(raw.speed || 0),
            reactionMs: raw.reactionMs,
        };
    }
    if (Array.isArray(frame?.pointer) && frame.pointer.length >= 2) {
        return {
            x: Number(frame.pointer[0] || 0),
            y: Number(frame.pointer[1] || 0),
            speed: 0,
            reactionMs: null,
        };
    }
    return null;
}

function drawPointer(pointer, frameWidth, frameHeight, scaleX, scaleY) {
    if (!ctx || !pointer) {
        return;
    }
    const px = clamp(pointer.x, 0, frameWidth) * scaleX;
    const py = clamp(pointer.y, 0, frameHeight) * scaleY;
    ctx.fillStyle = 'rgba(0, 255, 170, 0.9)';
    ctx.beginPath();
    ctx.arc(px, py, 5.5, 0, Math.PI * 2);
    ctx.fill();

    ctx.strokeStyle = 'rgba(0, 255, 170, 0.65)';
    ctx.beginPath();
    ctx.arc(px, py, 13, 0, Math.PI * 2);
    ctx.stroke();
}

function drawOverlay(frame) {
    if (!ctx || !canvas || !overlayState.enabled) {
        return;
    }

    clearOverlay();
    drawCrosshair();

    const frameWidth = Math.max(1, Number(frame.frame_width || overlayWidth));
    const frameHeight = Math.max(1, Number(frame.frame_height || overlayHeight));
    const scaleX = canvas.width / frameWidth;
    const scaleY = canvas.height / frameHeight;

    const objects = Array.isArray(frame.objects) ? frame.objects.slice(0, overlayState.maxTargets) : [];
    const selected = frame.selected_target || objects[0] || null;

    if (!objects.length) {
        trails.clear();
        drawNoDetectionState();
        return;
    }

    const activeTrailIds = new Set();
    objects.forEach((obj) => {
        const [x, y, w, h] = obj.bbox || [0, 0, 0, 0];
        const cx = Number(obj.center?.[0] || 0);
        const cy = Number(obj.center?.[1] || 0);
        const drawX = x * scaleX;
        const drawY = y * scaleY;
        const drawW = w * scaleX;
        const drawH = h * scaleY;
        const isSelected = Boolean(selected && selected.id === obj.id);
        const boxFill = hexToRgba(overlayState.boxColor, overlayState.opacity);
        const boxStroke = hexToRgba(overlayState.boxColor, isSelected ? 1 : 0.95);

        ctx.shadowBlur = overlayState.boxGlow ? 10 : 0;
        ctx.shadowColor = overlayState.boxGlow ? hexToRgba(overlayState.boxColor, 0.45) : 'transparent';
        ctx.strokeStyle = boxStroke;
        ctx.lineWidth = Math.max(1, isSelected ? overlayState.boxThickness + 1 : overlayState.boxThickness);
        ctx.strokeRect(drawX, drawY, drawW, drawH);

        ctx.shadowBlur = 0;
        ctx.fillStyle = boxFill;
        ctx.fillRect(drawX, drawY, drawW, drawH);

        if (overlayState.showLabels) {
            ctx.fillStyle = '#ffffff';
            ctx.font = `${overlayState.fontSize}px monospace`;
            const label = `${obj.label || obj.class || 'target'} #${obj.id || '?'} ${Math.round((obj.confidence || 0) * 100)}%`;
            ctx.fillText(label, drawX + 6, drawY + overlayState.fontSize + 4);
        }

        if (overlayState.trailEnabled) {
            const key = String(obj.id || `${Math.round(cx)}-${Math.round(cy)}`);
            activeTrailIds.add(key);
            const trail = trails.get(key) || [];
            trail.push({ x: cx * scaleX, y: cy * scaleY });
            while (trail.length > overlayState.trailLength) {
                trail.shift();
            }
            trails.set(key, trail);
            if (trail.length > 1) {
                ctx.beginPath();
                ctx.strokeStyle = hexToRgba(overlayState.trailColor, overlayState.trailOpacity);
                ctx.lineWidth = Math.max(1, overlayState.trailThickness);
                ctx.moveTo(trail[0].x, trail[0].y);
                trail.forEach((point) => ctx.lineTo(point.x, point.y));
                ctx.stroke();
            }
        }

        if (overlayState.showIndicators && Array.isArray(obj.velocity)) {
            const velocity = obj.velocity.map((v) => v * overlayState.velocitySensitivity);
            const arrowStartX = cx * scaleX;
            const arrowStartY = cy * scaleY;
            const arrowEndX = arrowStartX + velocity[0] * 0.6;
            const arrowEndY = arrowStartY + velocity[1] * 0.6;
            ctx.beginPath();
            ctx.strokeStyle = hexToRgba(overlayState.boxColor, 0.95);
            ctx.lineWidth = 1.8;
            ctx.moveTo(arrowStartX, arrowStartY);
            ctx.lineTo(arrowEndX, arrowEndY);
            ctx.stroke();
            ctx.beginPath();
            ctx.arc(arrowEndX, arrowEndY, 4, 0, Math.PI * 2);
            ctx.fillStyle = hexToRgba(overlayState.boxColor, 0.9);
            ctx.fill();
        }

        const predicted = Array.isArray(obj.predicted_center) ? obj.predicted_center : null;
        if (predicted && overlayState.predictionStrength > 0) {
            const predictedX = Number(predicted[0] || 0) * scaleX;
            const predictedY = Number(predicted[1] || 0) * scaleY;
            const currentX = cx * scaleX;
            const currentY = cy * scaleY;
            ctx.beginPath();
            ctx.strokeStyle = hexToRgba(overlayState.boxColor, 0.75);
            ctx.lineWidth = 1.5;
            ctx.setLineDash([6, 4]);
            ctx.moveTo(currentX, currentY);
            ctx.lineTo(predictedX, predictedY);
            ctx.stroke();
            ctx.setLineDash([]);
            ctx.fillStyle = hexToRgba(overlayState.boxColor, 0.6);
            ctx.beginPath();
            ctx.arc(predictedX, predictedY, 7, 0, Math.PI * 2);
            ctx.fill();
        }
    });

    trails.forEach((_, key) => {
        if (!activeTrailIds.has(key)) {
            trails.delete(key);
        }
    });

    if (selected) {
        const centerX = canvas.width / 2;
        const centerY = canvas.height / 2;
        const targetX = Number(selected.center?.[0] || 0) * scaleX;
        const targetY = Number(selected.center?.[1] || 0) * scaleY;
        ctx.strokeStyle = 'rgba(255, 240, 120, 0.95)';
        ctx.lineWidth = 2.1;
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(targetX, targetY);
        ctx.stroke();
        ctx.fillStyle = 'rgba(255, 240, 120, 0.3)';
        ctx.beginPath();
        ctx.arc(targetX, targetY, 10, 0, Math.PI * 2);
        ctx.fill();
    }

    if (overlayState.showFPS && Number(frame.fps)) {
        ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
        ctx.font = `${overlayState.fontSize + 2}px monospace`;
        ctx.fillText(`${Number(frame.fps).toFixed(1)} FPS`, canvas.width - 100, 26);
    }

    drawPointer(resolvePointer(frame), frameWidth, frameHeight, scaleX, scaleY);
}

function analyzeFrame(frame) {
    const objects = Array.isArray(frame.objects) ? frame.objects : [];
    const selected = frame.selected_target || objects[0] || null;
    const frameWidth = Math.max(1, Number(frame.frame_width || overlayWidth));
    const frameHeight = Math.max(1, Number(frame.frame_height || overlayHeight));
    const pointer = resolvePointer(frame);

    let offset = [0, 0];
    if (Array.isArray(frame.aim_offset) && frame.aim_offset.length >= 2) {
        offset = [Number(frame.aim_offset[0] || 0), Number(frame.aim_offset[1] || 0)];
    } else if (selected && Array.isArray(selected.center)) {
        offset = [Number(selected.center[0] || 0) - frameWidth / 2, Number(selected.center[1] || 0) - frameHeight / 2];
    }

    pushBounded(analysisState.offsets, { x: offset[0], y: offset[1], ts: Date.now() }, 300);

    const previous = analysisState.offsets.length > 1 ? analysisState.offsets[analysisState.offsets.length - 2] : null;
    if (
        previous &&
        Math.sign(previous.x) !== Math.sign(offset[0]) &&
        Math.abs(previous.x) > 35 &&
        Math.abs(offset[0]) > 35
    ) {
        analysisState.overFlickEvents += 1;
    }

    if (selected && selected.id !== analysisState.currentTargetId) {
        analysisState.currentTargetId = selected.id;
        analysisState.reactionStartTs = Date.now();
    }

    const offsetMagnitude = Math.hypot(offset[0], offset[1]);
    if (analysisState.reactionStartTs && offsetMagnitude < 45) {
        pushBounded(analysisState.reactionSamples, Date.now() - analysisState.reactionStartTs, 40);
        analysisState.reactionStartTs = null;
    }

    if (pointer && selected && Array.isArray(selected.center)) {
        const distance = Math.hypot(pointer.x - selected.center[0], pointer.y - selected.center[1]);
        const maxDistance = Math.hypot(frameWidth, frameHeight);
        const accuracy = clamp(100 - (distance / maxDistance) * 100, 0, 100);
        pushBounded(analysisState.pointerDistances, accuracy, 300);
        pushBounded(analysisState.pointerSpeeds, Number(pointer.speed || 0), 300);
    }

    const avgOffsetY = avg(analysisState.offsets.map((entry) => entry.y));
    const avgOffsetMag = avg(analysisState.offsets.map((entry) => Math.hypot(entry.x, entry.y)));
    const reactionMs = Math.round(avg(analysisState.reactionSamples) || Number(pointer?.reactionMs || 0));
    const trackingAccuracy = Math.round(avg(analysisState.pointerDistances));
    const overFlickRate = analysisState.overFlickEvents / Math.max(1, analysisState.offsets.length);

    const weaknesses = [];
    const coaching = [];

    if (avgOffsetY < -20) {
        weaknesses.push('crosshair too high');
        coaching.push('Crosshair placement too high.');
    } else if (avgOffsetY > 20) {
        weaknesses.push('crosshair too low');
        coaching.push('Crosshair placement too low.');
    }

    if (reactionMs > 0 && reactionMs > 250) {
        weaknesses.push('reaction delay');
        coaching.push('Reaction delay increased.');
    }

    if (trackingAccuracy > 0 && trackingAccuracy < 70) {
        weaknesses.push('tracking weakness');
        coaching.push('Tracking weak during strafes.');
    }

    if (overFlickRate > 0.17) {
        weaknesses.push('overflick tendency');
        coaching.push('Overflick tendency detected.');
    }

    if (avgOffsetMag > 130) {
        weaknesses.push('undershooting');
        coaching.push('Undershooting target center; commit to full correction.');
    }

    if (!coaching.length) {
        coaching.push('Aim control stable. Maintain center-screen discipline.');
    }

    let playerType = 'Developing Tracker';
    if (trackingAccuracy >= 82 && (reactionMs > 0 ? reactionMs <= 200 : true)) {
        playerType = 'Aggressive Tracker';
    } else if (trackingAccuracy >= 74) {
        playerType = 'Balanced Tracker';
    } else if (overFlickRate > 0.2) {
        playerType = 'Reactive Flicker';
    }

    safeText(dom.reactionTime, reactionMs > 0 ? `${reactionMs} ms` : '-- ms');
    safeText(dom.trackingAccuracy, `${Math.max(0, trackingAccuracy)}%`);
    safeText(dom.profilePlayerType, playerType);
    safeText(dom.profileReaction, reactionMs > 0 ? `${reactionMs}` : '--');
    safeText(dom.profileAccuracy, `${Math.max(0, trackingAccuracy)}`);
    safeText(dom.profileWeaknesses, weaknesses.length ? weaknesses.join(', ') : 'None');

    safeText(dom.coachingPrimary, coaching[0]);
    if (dom.coachingList) {
        dom.coachingList.innerHTML = '';
        coaching.slice(0, 4).forEach((message) => {
            const li = document.createElement('li');
            li.textContent = message;
            dom.coachingList.appendChild(li);
        });
    }

    setDiagState(diagDom.coaching, coaching.length > 0);

    return {
        playerType,
        reactionTime: reactionMs > 0 ? reactionMs : null,
        trackingAccuracy: Math.max(0, trackingAccuracy),
        weaknesses,
    };
}

function setRunningState(nextRunning) {
    isRunning = Boolean(nextRunning);
    if (dom.startBtn) {
        dom.startBtn.classList.toggle('active', isRunning);
        dom.startBtn.innerHTML = `<span class="status-dot"></span>${isRunning ? 'STOP' : 'START'}`;
    }
    if (dom.workingDot) {
        dom.workingDot.classList.toggle('active', isRunning);
    }
    if (dom.aimbotToggle && dom.aimbotToggle.checked !== isRunning) {
        dom.aimbotToggle.checked = isRunning;
    }
    if (!isRunning) {
        clearOverlay();
    }
}

function toggleAssistant(forceState = null) {
    const desired = forceState === null ? !isRunning : Boolean(forceState);
    setRunningState(desired);
    if (window.api?.toggleAssistant) {
        window.api.toggleAssistant(desired);
    }
    safeText(dom.workingText, desired ? '🔴 RUNNING - AI Aim is active' : '⚪ STOPPED - Click START to begin');
}

function saveSettings() {
    const settings = {
        sensitivity: parseFloat(document.getElementById('sensitivity').value),
        smoothing: parseFloat(document.getElementById('smoothing').value),
        confidenceThreshold: parseFloat(document.getElementById('confidence-threshold').value),
        updateInterval: parseInt(document.getElementById('update-interval').value, 10),
        trackingMode: document.getElementById('tracking-mode').value,
        trailLength: parseInt(document.getElementById('trail-length').value, 10),
        trailOpacity: parseFloat(document.getElementById('trail-opacity').value),
        predictionSmoothness: parseFloat(document.getElementById('prediction-smoothness').value),
        predictionStrength: parseFloat(document.getElementById('prediction-strength').value),
        overlayEnabled: document.getElementById('overlay-enabled').checked,
        overlayOpacity: parseFloat(document.getElementById('overlay-opacity').value),
        overlayTransparency: parseFloat(document.getElementById('overlay-transparency').value),
        trailEnabled: document.getElementById('trail-enabled').checked,
        boxColor: document.getElementById('box-color').value,
        boxThickness: parseInt(document.getElementById('box-thickness').value, 10),
        boxGlow: document.getElementById('box-glow').checked,
        labelVisibility: document.getElementById('label-visibility').checked,
        indicatorVisibility: document.getElementById('indicator-visibility').checked,
        fontSize: parseInt(document.getElementById('font-size').value, 10),
        maxTargets: parseInt(document.getElementById('max-targets').value, 10),
        fpsTarget: parseInt(document.getElementById('fps-target').value, 10),
        velocitySensitivity: parseFloat(document.getElementById('velocity-sensitivity').value),
        lockDuration: parseInt(document.getElementById('lock-duration').value, 10),
        detectionSensitivity: parseFloat(document.getElementById('confidence-threshold').value),
    };

    overlayState.enabled = settings.overlayEnabled;
    overlayState.opacity = settings.overlayOpacity;
    overlayState.trailEnabled = settings.trailEnabled;
    overlayState.trailLength = settings.trailLength;
    overlayState.boxColor = settings.boxColor;
    overlayState.boxThickness = settings.boxThickness;
    overlayState.boxGlow = settings.boxGlow;
    overlayState.trailOpacity = settings.trailOpacity;
    overlayState.predictionStrength = settings.predictionStrength;
    overlayState.maxTargets = settings.maxTargets;
    overlayState.showLabels = settings.labelVisibility;
    overlayState.showIndicators = settings.indicatorVisibility;
    overlayState.fontSize = settings.fontSize;
    overlayState.showFPS = settings.fpsTarget > 0;
    overlayState.overlayTransparency = settings.overlayTransparency;
    overlayState.velocitySensitivity = settings.velocitySensitivity;

    if (window.api?.updateSettings) {
        window.api.updateSettings(settings);
    }
    safeText(dom.workingText, 'Settings updated and sent to backend.');
}

function attachSliderValue(id, outputId, formatter) {
    const input = document.getElementById(id);
    const output = document.getElementById(outputId);
    if (!input || !output) {
        return;
    }
    input.addEventListener('input', (event) => {
        output.textContent = formatter(event.target.value);
    });
}

function wireStaticUiEvents() {
    document.querySelectorAll('.menu-item').forEach((item) => {
        item.addEventListener('click', () => {
            const sectionId = item.dataset.section;
            document.querySelectorAll('.menu-item').forEach((node) => node.classList.remove('active'));
            document.querySelectorAll('.section').forEach((node) => node.classList.remove('active'));
            item.classList.add('active');
            document.getElementById(sectionId)?.classList.add('active');
        });
    });

    attachSliderValue('sensitivity', 'sensitivity-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('smoothing', 'smoothing-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('confidence-threshold', 'confidence-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('trail-length', 'trail-length-value', (value) => String(value));
    attachSliderValue('trail-opacity', 'trail-opacity-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('prediction-smoothness', 'prediction-smoothness-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('prediction-strength', 'prediction-strength-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('overlay-opacity', 'overlay-opacity-value', (value) => parseFloat(value).toFixed(1));
    attachSliderValue('overlay-transparency', 'overlay-transparency-value', (value) => parseFloat(value).toFixed(2));
    attachSliderValue('box-thickness', 'box-thickness-value', (value) => String(value));
    attachSliderValue('font-size', 'font-size-value', (value) => String(value));
    attachSliderValue('velocity-sensitivity', 'velocity-sensitivity-value', (value) => parseFloat(value).toFixed(2));

    if (dom.aimbotToggle) {
        dom.aimbotToggle.addEventListener('change', (event) => toggleAssistant(event.target.checked));
    }
}

function wireAssistantEvents() {
    if (!window.api) {
        safeText(dom.workingText, 'IPC bridge unavailable. Check preload configuration.');
        return;
    }

    window.api.onAssistantFrame((frame) => {
        if (!frame || frame.type !== 'detection') {
            return;
        }
        updateCount += 1;

        overlayWidth = Number(frame.frame_width || overlayWidth);
        overlayHeight = Number(frame.frame_height || overlayHeight);
        const objects = Array.isArray(frame.objects) ? frame.objects : [];
        const selected = frame.selected_target || objects[0] || {};
        const pointer = resolvePointer(frame);
        const behavior = frame.behavior || {};

        safeText(dom.modelStatus, `✅ ${frame.source || 'active'} • ${Number(frame.fps || 0).toFixed(2)} FPS`);
        safeText(dom.confidence, `${Math.round((selected.confidence || 0) * 100)}%`);
        safeText(dom.aimCorrection, `${Math.round(frame.aim_offset?.[0] || 0)}, ${Math.round(frame.aim_offset?.[1] || 0)}`);
        safeText(dom.targetCount, String(objects.length));
        safeText(dom.detectionSource, `${frame.source || 'unknown'} • ${behavior.engagement || 'unknown'}`);

        if (pointer) {
            safeText(dom.pointerPos, `${Math.round(pointer.x)}, ${Math.round(pointer.y)}`);
            safeText(dom.velocity, `${Math.round(pointer.speed || 0)} px/s`);
        } else if (selected?.center) {
            safeText(dom.pointerPos, `${Math.round(selected.center[0])}, ${Math.round(selected.center[1])}`);
            safeText(dom.velocity, '0 px/s');
        } else {
            safeText(dom.pointerPos, '--, --');
            safeText(dom.velocity, '-- px/s');
        }

        if (!objects.length) {
            safeText(dom.confidence, '0%');
            safeText(dom.reactionTime, '-- ms');
            safeText(dom.trackingAccuracy, '0%');
            safeText(dom.profileWeaknesses, 'No target lock');
            safeText(dom.coachingPrimary, 'No detections yet. Keep crosshair near center and maintain visibility.');
        }

        if (pointer) {
            safeText(dom.pointerPos, `${Math.round(pointer.x)}, ${Math.round(pointer.y)}`);
            safeText(dom.velocity, `${Math.round(pointer.speed || 0)} px/s`);
        } else if (selected?.center) {
            safeText(dom.pointerPos, `${Math.round(selected.center[0])}, ${Math.round(selected.center[1])}`);
            safeText(dom.velocity, '0 px/s');
        } else {
            safeText(dom.pointerPos, '--, --');
            safeText(dom.velocity, '-- px/s');
        }

        if (!objects.length) {
            safeText(dom.confidence, '0%');
            safeText(dom.reactionTime, '-- ms');
            safeText(dom.trackingAccuracy, '0%');
            safeText(dom.profileWeaknesses, 'No target lock');
            safeText(dom.coachingPrimary, 'No detections yet. Keep crosshair near center and maintain visibility.');
        }

        applyDiagnostics(frame.diagnostics);
        drawOverlay(frame);
        analyzeFrame(frame);
    });

    window.api.onAssistantStatus((status) => {
        if (status?.message) {
            safeText(dom.workingText, status.message);
            safeText(dom.modelStatus, `⚠️ ${status.message}`);
        }
        applyDiagnostics(status?.diagnostics);
    });

    window.api.onAssistantOutput((evt) => {
        assistantOutputCount += 1;
        if (assistantOutputCount > 0) {
            setDiagState(diagDom.json, true);
        }
        if (evt && evt.parsed === false) {
            safeText(dom.workingText, `Parser warning: non-JSON detector line #${evt.stdoutLineNumber || '?'}`);
        }
    });

    window.api.onAssistantError((error) => {
        safeText(dom.workingText, `⚠️ Error: ${String(error)}`);
    });

    window.api.onAssistantStarted(() => {
        setRunningState(true);
        safeText(dom.workingText, '🔴 RUNNING - AI Aim is active');
        setDiagState(diagDom.online, true);
        setDiagState(diagDom.renderer, true);
        setDiagState(diagDom.ipc, true);
    });

    window.api.onAssistantStopped(() => {
        setRunningState(false);
        safeText(dom.workingText, '⚪ STOPPED - Click START to begin');
        setDiagState(diagDom.online, false);
    });

    window.api.onSettingsApplied((settings) => {
        safeText(
            dom.workingText,
            `Settings applied (confidence=${Number(settings?.confidenceThreshold || 0).toFixed(2)} smoothing=${Number(settings?.smoothing || 0).toFixed(2)})`,
        );
    });

    window.api.onAssistantLog((line) => {
        console.warn('assistant-log:', line);
    });
}

setInterval(() => {
    safeText(dom.updatesPerSec, String(updateCount));
    updateCount = 0;
}, 1000);

window.addEventListener('resize', resizeCanvas);
window.addEventListener('DOMContentLoaded', () => {
    resizeCanvas();
    wireStaticUiEvents();
    wireAssistantEvents();
    setDiagState(diagDom.renderer, true);
    setDiagState(diagDom.ipc, Boolean(window.api));
});

window.toggleAssistant = toggleAssistant;
window.saveSettings = saveSettings;

