import ctypes
import json
import math
import os
import sys
import time

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
TORCH_CACHE_DIR = os.path.normpath(os.path.join(SCRIPT_DIR, '..', '.cache', 'torch'))
os.makedirs(TORCH_CACHE_DIR, exist_ok=True)
os.makedirs(os.path.join(SCRIPT_DIR, 'models'), exist_ok=True)
os.environ.setdefault('TORCH_HOME', TORCH_CACHE_DIR)
os.environ.setdefault('TORCH_MODEL_ZOO', TORCH_CACHE_DIR)

TORCH_AVAILABLE = False
OPENCV_AVAILABLE = False
NUMPY_AVAILABLE = False
MSS_AVAILABLE = False

torch_error = None
cv2_error = None
np_error = None
mss_error = None

try:
    import torch
    TORCH_AVAILABLE = True
except Exception as exc:
    TORCH_AVAILABLE = False
    torch_error = str(exc)

try:
    import cv2
    OPENCV_AVAILABLE = True
except Exception as exc:
    OPENCV_AVAILABLE = False
    cv2_error = str(exc)

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except Exception as exc:
    NUMPY_AVAILABLE = False
    np_error = str(exc)

try:
    import mss
    MSS_AVAILABLE = True
except Exception as exc:
    MSS_AVAILABLE = False
    mss_error = str(exc)

FILTERPY_AVAILABLE = False
filterpy_error = None
try:
    from filterpy.kalman import KalmanFilter
    FILTERPY_AVAILABLE = True
except Exception as exc:
    FILTERPY_AVAILABLE = False
    filterpy_error = str(exc)

class Track:
    def __init__(self, object_id, class_name, bbox, center, confidence):
        self.id = object_id
        self.class_name = class_name
        self.bbox = bbox
        self.center = center
        self.confidence = confidence
        self.velocity = [0.0, 0.0]
        self.direction = [0.0, 0.0]
        self.trail = [center]
        self.last_seen = 0
        self.predicted = center[:]
        self._use_kalman = FILTERPY_AVAILABLE
        self.kf = None
        if self._use_kalman:
            try:
                kf = KalmanFilter(dim_x=4, dim_z=2)
                dt = 1.0
                # state: x, y, vx, vy
                kf.F = np.array([[1, 0, dt, 0], [0, 1, 0, dt], [0, 0, 1, 0], [0, 0, 0, 1]])
                kf.H = np.array([[1, 0, 0, 0], [0, 1, 0, 0]])
                kf.P *= 500.
                kf.R = np.eye(2) * 5.
                kf.Q = np.eye(4) * 0.01
                kf.x = np.array([center[0], center[1], 0., 0.])
                self.kf = kf
            except Exception:
                self._use_kalman = False

    def update(self, bbox, center, confidence):
        dx = center[0] - self.center[0]
        dy = center[1] - self.center[1]
        # raw observed delta
        self.velocity = [dx, dy]
        self.direction = [dx, dy]
        self.bbox = bbox
        self.confidence = confidence

        if self._use_kalman and self.kf is not None:
            try:
                self.kf.predict()
                self.kf.update(np.array([center[0], center[1]]))
                px, py = float(self.kf.x[0]), float(self.kf.x[1])
                self.center = [px, py]
                self.predicted = [px + float(self.kf.x[2]), py + float(self.kf.x[3])]
            except Exception:
                self.center = center
                self.predicted = [center[0] + dx * 0.5, center[1] + dy * 0.5]
        else:
            # exponential smoothing fallback
            smoothed_x = self.center[0] + dx * 0.6
            smoothed_y = self.center[1] + dy * 0.6
            self.center = [smoothed_x, smoothed_y]
            self.predicted = [self.center[0] + dx * 0.5, self.center[1] + dy * 0.5]

        self.trail.append(self.center)
        if len(self.trail) > 40:
            self.trail.pop(0)
        self.last_seen = 0

class CentroidTracker:
    def __init__(self, max_distance=120, max_lost=10):
        self.next_id = 1
        self.objects = {}
        self.max_distance = max_distance
        self.max_lost = max_lost

    def update(self, detections):
        updated = {}

        for det in detections:
            best_id = None
            best_distance = float('inf')
            for object_id, track in self.objects.items():
                if track.class_name != det['class_name']:
                    continue
                distance = math.hypot(track.center[0] - det['center'][0], track.center[1] - det['center'][1])
                if distance < best_distance and distance < self.max_distance:
                    best_distance = distance
                    best_id = object_id

            if best_id is None:
                track = Track(self.next_id, det['class_name'], det['bbox'], det['center'], det['confidence'])
                self.objects[self.next_id] = track
                updated[self.next_id] = track
                self.next_id += 1
            else:
                track = self.objects[best_id]
                track.update(det['bbox'], det['center'], det['confidence'])
                updated[best_id] = track

        for object_id, track in list(self.objects.items()):
            if object_id not in updated:
                track.last_seen += 1
                if track.last_seen > self.max_lost:
                    del self.objects[object_id]

        return [self._serialize(track) for track in updated.values()]

    def _serialize(self, track):
        return {
            'id': track.id,
            'class': track.class_name,
            'bbox': [round(track.bbox[0], 2), round(track.bbox[1], 2), round(track.bbox[2], 2), round(track.bbox[3], 2)],
            'center': [round(track.center[0], 2), round(track.center[1], 2)],
            'confidence': round(track.confidence, 3),
            'velocity': [round(track.velocity[0], 2), round(track.velocity[1], 2)],
            'direction': [round(track.direction[0], 2), round(track.direction[1], 2)],
            'predicted_center': [round(track.predicted[0], 2), round(track.predicted[1], 2)] if hasattr(track, 'predicted') else None,
        }


def send_line(payload):
    sys.stdout.write(json.dumps(payload) + '\n')
    sys.stdout.flush()


def get_pointer_position():
    try:
        if os.name == 'nt':
            class POINT(ctypes.Structure):
                _fields_ = [('x', ctypes.c_long), ('y', ctypes.c_long)]

            pt = POINT()
            if ctypes.windll.user32.GetCursorPos(ctypes.byref(pt)):
                return [float(pt.x), float(pt.y)]
    except Exception:
        pass

    try:
        import pyautogui
        pos = pyautogui.position()
        return [float(pos.x), float(pos.y)]
    except Exception:
        return None


def categorize_detection(class_name, confidence=0.0):
    label = str(class_name).lower()
    if any(token in label for token in ('person', 'player', 'human', 'soldier', 'agent', 'man', 'woman', 'boy', 'girl')):
        return 'enemy'
    if any(token in label for token in ('robot', 'android', 'mech', 'drone')):
        return 'robot'
    if any(token in label for token in ('gun', 'rifle', 'weapon', 'knife', 'ammo', 'explosive', 'grenade')):
        return 'threat'
    if confidence >= 0.55:
        return 'threat'
    return 'target'


# Screen capture only. Webcam and capture card device probing are disabled.
# We use MSS to capture the desktop screen or the primary monitor region.


def select_screen_monitor(sct):
    monitors = sct.monitors[1:] if len(sct.monitors) > 1 else sct.monitors
    if not monitors:
        return None
    primary = monitors[0]
    best = max(monitors, key=lambda m: m['width'] * m['height'])
    return best or primary


def load_yolo_model():
    # Prefer the ultralytics YOLO API when available (v8+), otherwise fallback to torch hub
    model = None
    model_dir = os.path.join(SCRIPT_DIR, 'models')
    weights_v8 = os.path.join(model_dir, 'yolov8n.pt')
    weights_v5 = os.path.join(model_dir, 'yolov5s.pt')
    alternative_v8 = os.path.normpath(os.path.join(SCRIPT_DIR, '..', 'yolov8n.pt'))

    device = 'cuda' if (TORCH_AVAILABLE and torch.cuda.is_available()) else 'cpu'
    try:
        from ultralytics import YOLO
        # use local weights if present, otherwise try the small pretrained model name
        if os.path.exists(weights_v8):
            weight_path = weights_v8
        elif os.path.exists(alternative_v8):
            weight_path = alternative_v8
        else:
            weight_path = None

        if weight_path:
            send_line({'type': 'status', 'message': f'Loading YOLOv8 weights from {weight_path} on {device}'})
            model = YOLO(weight_path, device=device)
        else:
            send_line({'type': 'status', 'message': f'Local YOLOv8 weights missing; trying pretrained yolov8n on {device}.'})
            model = YOLO('yolov8n', device=device)

        # warmup if possible
        try:
            model.predict(np.zeros((1, 320, 320, 3), dtype=np.uint8), device=device)
        except Exception:
            pass

        send_line({'type': 'status', 'message': 'YOLO (ultralytics) model ready.'})
        return model
    except Exception:
        # fallback to torch hub / yolov5 if torch is available
        if TORCH_AVAILABLE:
            try:
                torch.hub.set_dir(TORCH_CACHE_DIR)
                device = 'cuda' if torch.cuda.is_available() else 'cpu'
                if os.path.exists(weights_v5):
                    send_line({'type': 'status', 'message': f'Loading YOLOv5 weights from {weights_v5} on {device}'})
                    model = torch.hub.load('ultralytics/yolov5', 'custom', path=weights_v5, source='local', device=device)
                else:
                    send_line({'type': 'status', 'message': f'Local YOLOv5 weights missing; loading yolov5s from GitHub on {device}.'})
                    model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True, verbose=False, source='github', device=device)
                if hasattr(model, 'to'):
                    model = model.to(device)
                model.conf = 0.35
                model.iou = 0.45
                send_line({'type': 'status', 'message': 'YOLO (torch hub) model ready.'})
                return model
            except Exception as exc:
                global torch_error
                torch_error = str(exc)
                send_line({'type': 'status', 'message': f'YOLO model load failed: {torch_error}'})
                return None
        else:
            send_line({'type': 'status', 'message': 'No supported YOLO backend available (ultralytics or torch).'} )
            return None


def get_detection_candidates(frame, model):
    detections = []

    if model is None:
        return detections

    try:
        results = model(frame)
    except Exception as exc:
        send_line({'type': 'status', 'message': f'YOLO inference failed: {exc}'})
        return detections
    # Support both ultralytics (YOLOv8) and torch-hub yolov5 outputs
    try:
        # Torch hub yolov5 results have .xyxy
        if hasattr(results, 'xyxy') and len(results.xyxy) > 0:
            items = results.xyxy[0].cpu().numpy()
            class_names = getattr(results, 'names', {})
            for item in items:
                x1, y1, x2, y2, conf, class_id = item.tolist()
                if conf < 0.3:
                    continue
                raw_name = class_names[int(class_id)] if int(class_id) in class_names else str(int(class_id))
                category = categorize_detection(raw_name, float(conf))
                bbox = [float(x1), float(y1), float(x2 - x1), float(y2 - y1)]
                center = [float((x1 + x2) / 2), float((y1 + y2) / 2)]
                detections.append({
                    'class_name': category,
                    'label': raw_name,
                    'bbox': bbox,
                    'center': center,
                    'confidence': float(conf),
                })
            return detections
    except Exception:
        pass

    # ultralytics YOLOv8 style
    try:
        res0 = results[0] if (isinstance(results, (list, tuple)) and len(results) > 0) else results
        boxes = getattr(res0, 'boxes', None)
        if boxes is None:
            return detections

        # boxes.xyxy may be a Tensor-like or array
        xyxy = getattr(boxes, 'xyxy', None)
        confs = getattr(boxes, 'conf', None)
        clss = getattr(boxes, 'cls', None)

        if xyxy is None:
            return detections

        # convert to numpy
        try:
            items = xyxy.cpu().numpy() if hasattr(xyxy, 'cpu') else np.array(xyxy)
        except Exception:
            items = np.array(xyxy)

        confs_np = None
        clss_np = None
        try:
            if confs is not None:
                confs_np = confs.cpu().numpy() if hasattr(confs, 'cpu') else np.array(confs)
            if clss is not None:
                clss_np = clss.cpu().numpy() if hasattr(clss, 'cpu') else np.array(clss)
        except Exception:
            confs_np = None
            clss_np = None

        names = getattr(model, 'names', {}) or {}

        for i, box in enumerate(items):
            x1, y1, x2, y2 = box[:4]
            conf = float(confs_np[i]) if (confs_np is not None and len(confs_np) > i) else float(box[4]) if box.shape[0] > 4 else 0.0
            if conf < 0.3:
                continue
            class_id = int(clss_np[i]) if (clss_np is not None and len(clss_np) > i) else int(box[5]) if box.shape[0] > 5 else 0
            raw_name = names.get(class_id, str(class_id))
            category = categorize_detection(raw_name, float(conf))
            bbox = [float(x1), float(y1), float(x2 - x1), float(y2 - y1)]
            center = [float((x1 + x2) / 2), float((y1 + y2) / 2)]
            detections.append({
                'class_name': category,
                'label': raw_name,
                'bbox': bbox,
                'center': center,
                'confidence': float(conf),
            })
        return detections
    except Exception as exc:
        send_line({'type': 'status', 'message': f'Detection parsing failed: {exc}'})
        return detections



class MotionDetector:
    def __init__(self, min_area=1500):
        self.subtractor = cv2.createBackgroundSubtractorMOG2(history=300, varThreshold=25, detectShadows=True)
        self.kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        self.min_area = min_area

    def detect(self, frame):
        detections = []
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (7, 7), 0)
        fgmask = self.subtractor.apply(blur)
        _, thresh = cv2.threshold(fgmask, 244, 255, cv2.THRESH_BINARY)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, self.kernel, iterations=2)
        thresh = cv2.morphologyEx(thresh, cv2.MORPH_OPEN, self.kernel, iterations=1)
        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        for contour in contours:
            if cv2.contourArea(contour) < self.min_area:
                continue
            x, y, w, h = cv2.boundingRect(contour)
            center = [float(x + w / 2), float(y + h / 2)]
            detections.append({
                'class_name': 'enemy',
                'bbox': [float(x), float(y), float(w), float(h)],
                'center': center,
                'confidence': 0.55,
            })

        return detections


def analyze_behavior(selected, aim_offset, history):
    status = 'searching'
    if selected and selected.get('confidence', 0) >= 0.45:
        status = 'engaged'

    trend = 'stable'
    if history and len(history) >= 2:
        dx = history[-1][0] - history[0][0]
        dy = history[-1][1] - history[0][1]
        if abs(dx) > abs(dy):
            trend = 'horizontal' if abs(dx) > 20 else 'stable'
        else:
            trend = 'vertical' if abs(dy) > 20 else 'stable'

    return {
        'engagement': status,
        'aim_trend': trend,
        'aim_offset': aim_offset,
    }


def main():
    model = load_yolo_model()
    if model is None:
        reason = 'YOLO unavailable'
        if not TORCH_AVAILABLE:
            reason = 'PyTorch not installed or failed to import.'
        elif torch_error:
            reason = f'YOLO load failed: {torch_error}'
        send_line({'type': 'status', 'message': f'{reason} Falling back to motion-based detection only.'})

    tracker = CentroidTracker()
    motion_detector = MotionDetector() if OPENCV_AVAILABLE and NUMPY_AVAILABLE else None
    frame_index = 0
    sct = None
    monitor = None
    behavior_history = []

    if MSS_AVAILABLE and NUMPY_AVAILABLE:
        try:
            sct = mss.MSS()
            monitor = select_screen_monitor(sct)
            if not monitor:
                raise RuntimeError('No monitor available for screen capture.')
            send_line({
                'type': 'status',
                'message': f"Screen capture ready ({monitor['width']}x{monitor['height']}) on monitor at ({monitor['left']}, {monitor['top']})."
            })
        except Exception as exc:
            sct = None
            mss_error = str(exc)
            send_line({'type': 'status', 'message': f'Screen capture init failed: {mss_error}'})
    else:
        send_line({'type': 'status', 'message': 'Screen capture unavailable because MSS or NumPy is missing.'})

    if sct is None:
        send_line({'type': 'status', 'message': 'Desktop capture unavailable. Application needs MSS screen capture to run.'})
        return

    try:
        while True:
            frame_index += 1
            start_time = time.time()
            pointer_screen = get_pointer_position() or [0.0, 0.0]
            source_name = 'screen'

            screenshot = sct.grab(monitor)
            frame = np.array(screenshot)[..., :3]
            frame_height, frame_width = frame.shape[:2]

            monitor_left = float(monitor.get('left', 0))
            monitor_top = float(monitor.get('top', 0))
            pointer = [
                round(pointer_screen[0] - monitor_left, 2),
                round(pointer_screen[1] - monitor_top, 2),
            ]

            detections = get_detection_candidates(frame, model)
            if not detections and motion_detector is not None:
                detections = motion_detector.detect(frame)
                if detections:
                    source_name = 'motion'

            tracked_objects = tracker.update(detections)
            selected = None
            if tracked_objects:
                selected = min(
                    tracked_objects,
                    key=lambda o: math.hypot(o['center'][0] - frame_width / 2, o['center'][1] - frame_height / 2),
                )
                selected_offset = [round(selected['center'][0] - frame_width / 2, 2), round(selected['center'][1] - frame_height / 2, 2)]
                behavior_history.append(selected['center'])
                if len(behavior_history) > 40:
                    behavior_history.pop(0)
            else:
                selected_offset = [0.0, 0.0]
                if frame_index % 90 == 0:
                    send_line({'type': 'status', 'message': 'No active detections in current frame window.'})

            fps = 1.0 / max(0.001, time.time() - start_time)
            behavior = analyze_behavior(selected, selected_offset, behavior_history)

            payload = {
                'type': 'detection',
                'frame': frame_index,
                'source': source_name,
                'frame_width': frame_width,
                'frame_height': frame_height,
                'objects': tracked_objects,
                'fps': round(fps, 2),
                'pointer': pointer,
                'pointer_screen': [round(pointer_screen[0], 2), round(pointer_screen[1], 2)],
                'behavior': behavior,
            }
            if selected:
                payload['selected_target'] = selected
                payload['aim_offset'] = selected_offset

            send_line(payload)

            elapsed = time.time() - start_time
            sleep_time = max(0, 0.033 - elapsed)
            time.sleep(sleep_time)
    except Exception as exc:
        send_line({'type': 'status', 'message': f'Detector crashed: {exc}'})

if __name__ == '__main__':
    main()
