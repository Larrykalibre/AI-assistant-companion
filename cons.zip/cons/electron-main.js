const { app, BrowserWindow, ipcMain, screen } = require('electron');
const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');

let robotjs = null;
let mainWindow = null;
let assistantProcess = null;
let stdoutBuffer = '';
let assistantLogPath = null;
let lastChecklistText = '';
let lastOffsetSpikeTs = null;
let lastRecoveredReactionMs = null;
const runtimeSettings = {
    confidenceThreshold: 0.7,
    overlayEnabled: true,
    smoothing: 0.12,
    predictionSmoothness: 0.4,
    boxColor: '#ffcc33',
    boxThickness: 2,
    boxOpacity: 0.28,
    boxGlow: true,
    trailColor: '#2affa0',
    trailLength: 28,
    trailOpacity: 0.5,
    trailThickness: 2,
    predictionStrength: 0.6,
    maxTargets: 12,
    showLabels: true,
    showIndicators: true,
    fontSize: 12,
    showFPS: true,
    overlayTransparency: 0.7,
    velocitySensitivity: 1.0,
    lockDuration: 10,
    detectionSensitivity: 0.7,
};

const runtimeStats = {
    launchedAt: null,
    jsonFrames: 0,
    detectionFrames: 0,
    statusFrames: 0,
    parseErrors: 0,
    ipcFrameSends: 0,
    ipcStatusSends: 0,
    lastStatusMessage: '',
    lastDetectionSource: '',
    rendererConnected: false,
    overlayReady: false,
    yoloLoaded: false,
    captureReady: false,
    assistantOnline: false,
    pointer: {
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        speed: 0,
        lastTs: 0,
    },
};

function getLogPath() {
    if (assistantLogPath) {
        return assistantLogPath;
    }
    let baseDir;
    try {
        baseDir = path.join(app.getPath('userData'), 'logs');
    } catch {
        baseDir = path.join(__dirname, 'logs');
    }
    fs.mkdirSync(baseDir, { recursive: true });
    assistantLogPath = path.join(baseDir, 'assistant.log');
    return assistantLogPath;
}

function safeLog(entry) {
    try {
        const line = JSON.stringify({ ts: Date.now(), ...entry }) + '\n';
        fs.appendFileSync(getLogPath(), line);
    } catch (error) {
        console.error('[assistant-log-write-failed]', error);
    }
}

function initRobotJs() {
    try {
        robotjs = require('robotjs');
        safeLog({ event: 'robotjs-loaded' });
    } catch (error) {
        robotjs = null;
        safeLog({ event: 'robotjs-load-failed', error: String(error) });
    }
}

function getDiagnosticsSnapshot() {
    return {
        backendLaunch: Boolean(assistantProcess),
        screenCaptureStarted: runtimeStats.captureReady,
        detectionRuns: runtimeStats.detectionFrames > 0,
        jsonFramesEmit: runtimeStats.jsonFrames > 0,
        electronParsesFrames: runtimeStats.jsonFrames > 0 && runtimeStats.parseErrors >= 0,
        ipcFrameFlow: runtimeStats.ipcFrameSends > 0,
        rendererConnected: runtimeStats.rendererConnected,
        overlayReady: runtimeStats.overlayReady,
        statusFlow: runtimeStats.statusFrames > 0,
        yoloLoaded: runtimeStats.yoloLoaded,
        assistantOnline: runtimeStats.assistantOnline,
        counters: {
            jsonFrames: runtimeStats.jsonFrames,
            detectionFrames: runtimeStats.detectionFrames,
            statusFrames: runtimeStats.statusFrames,
            parseErrors: runtimeStats.parseErrors,
            ipcFrameSends: runtimeStats.ipcFrameSends,
            ipcStatusSends: runtimeStats.ipcStatusSends,
        },
    };
}
function normalizeDetectionPayload(payload) {
    const frameWidth = Math.max(1, Number(payload?.frame_width || 1));
    const frameHeight = Math.max(1, Number(payload?.frame_height || 1));
    const threshold = Number.isFinite(Number(runtimeSettings.confidenceThreshold))
        ? Number(runtimeSettings.confidenceThreshold)
        : 0.7;

    const objects = Array.isArray(payload?.objects)
        ? payload.objects.filter((obj) => Number(obj?.confidence || 0) >= threshold)
        : [];

    let selected = payload?.selected_target || null;
    if (selected && Number(selected?.confidence || 0) < threshold) {
        selected = null;
    }
    if (!selected && objects.length) {
        selected = objects.reduce((best, obj) => {
            const bestDist = Math.hypot((best?.center?.[0] || 0) - frameWidth / 2, (best?.center?.[1] || 0) - frameHeight / 2);
            const nextDist = Math.hypot((obj?.center?.[0] || 0) - frameWidth / 2, (obj?.center?.[1] || 0) - frameHeight / 2);
            return nextDist < bestDist ? obj : best;
        }, objects[0]);
    }

    const normalized = {
        ...payload,
        objects,
    };

    if (selected) {
        normalized.selected_target = selected;
        normalized.aim_offset = [
            Number((Number(selected?.center?.[0] || 0) - frameWidth / 2).toFixed(2)),
            Number((Number(selected?.center?.[1] || 0) - frameHeight / 2).toFixed(2)),
        ];
    } else {
        delete normalized.selected_target;
        normalized.aim_offset = [0, 0];
    }

    return normalized;
}

function emitChecklistStatus() {
    const snapshot = getDiagnosticsSnapshot();
    const text = [
        `YOLO loaded=${snapshot.yoloLoaded ? 'YES' : 'NO'}`,
        `Capture ready=${snapshot.screenCaptureStarted ? 'YES' : 'NO'}`,
        `IPC connected=${snapshot.rendererConnected ? 'YES' : 'NO'}`,
        `Renderer connected=${snapshot.rendererConnected ? 'YES' : 'NO'}`,
        `Overlay ready=${snapshot.overlayReady ? 'YES' : 'NO'}`,
        `Assistant online=${snapshot.assistantOnline ? 'YES' : 'NO'}`,
    ].join(' | ');

    if (text === lastChecklistText) {
        return;
    }
    lastChecklistText = text;

    sendToRenderer('assistant-status', {
        type: 'status',
        message: `Startup validation: ${text}`,
        diagnostics: snapshot,
    });
    safeLog({ event: 'startup-checklist', text, snapshot });
}

function sendToRenderer(channel, payload) {
    if (!mainWindow || mainWindow.isDestroyed()) {
        safeLog({ event: 'ipc-send-skipped', channel, reason: 'window-unavailable' });
        return;
    }

    if (channel === 'assistant-frame') {
        runtimeStats.ipcFrameSends += 1;
    } else if (channel === 'assistant-status') {
        runtimeStats.ipcStatusSends += 1;
    }

    try {
        mainWindow.webContents.send(channel, payload);
        safeLog({ event: 'ipc-send', channel });
    } catch (error) {
        safeLog({ event: 'ipc-send-failed', channel, error: String(error) });
    }
}

function getAppRoot() {
    if (app.isPackaged) {
        return process.resourcesPath;
    }
    return __dirname;
}

function getDetectorLaunchConfig() {
    const appRoot = getAppRoot();
    const exeCandidates = [
        path.join(appRoot, 'ai', 'bin', 'ai_detector.exe'),
        path.join(__dirname, 'ai', 'bin', 'ai_detector.exe'),
    ];
    const exePath = exeCandidates.find((candidate) => fs.existsSync(candidate));

    const scriptCandidates = [
        path.join(__dirname, 'ai', 'detector.py'),
        path.join(appRoot, 'ai', 'detector.py'),
    ];
    const scriptPath = scriptCandidates.find((candidate) => fs.existsSync(candidate));

    const localVenvPython = path.join(__dirname, '.venv', 'Scripts', 'python.exe');
    const hasLocalVenv = fs.existsSync(localVenvPython);
    const pythonExe = hasLocalVenv ? localVenvPython : (process.platform === 'win32' ? 'python' : 'python3');

    const useBinary = Boolean(exePath) && process.platform === 'win32' && !hasLocalVenv;
    const command = useBinary ? exePath : pythonExe;
    const args = useBinary ? [] : (scriptPath ? [scriptPath] : []);

    return {
        appRoot,
        exePath: exePath || null,
        scriptPath: scriptPath || null,
        pythonExe,
        hasLocalVenv,
        useBinary,
        command,
        args,
    };
}

function processStatusPayload(payload) {
    const message = String(payload?.message || '');
    const lower = message.toLowerCase();
    runtimeStats.lastStatusMessage = message;
    runtimeStats.statusFrames += 1;

    if (lower.includes('yolo') && (lower.includes('ready') || lower.includes('model'))) {
        runtimeStats.yoloLoaded = true;
    }
    if (lower.includes('screen') || lower.includes('camera') || lower.includes('capture') || lower.includes('motion')) {
        runtimeStats.captureReady = true;
    }
    if (lower.includes('detector started') || lower.includes('online') || lower.includes('running')) {
        runtimeStats.assistantOnline = true;
    }
}

function getCursorPosition() {
    if (robotjs) {
        try {
            const pos = robotjs.getMousePos();
            return [Number(pos.x || 0), Number(pos.y || 0)];
        } catch (error) {
            safeLog({ event: 'robotjs-cursor-failed', error: String(error) });
        }
    }

    try {
        const cursor = screen.getCursorScreenPoint();
        return [Number(cursor.x || 0), Number(cursor.y || 0)];
    } catch (error) {
        safeLog({ event: 'electron-cursor-failed', error: String(error) });
        return null;
    }
}

function buildNodePointerTelemetry(framePayload) {
    const now = Date.now();
    const fallbackPointer = framePayload?.pointer || [0, 0];
    let point = { x: Number(fallbackPointer[0] || 0), y: Number(fallbackPointer[1] || 0) };
    const pointerScreen = Array.isArray(framePayload?.pointer_screen) ? framePayload.pointer_screen : null;

    if ((!Number.isFinite(point.x) || !Number.isFinite(point.y)) && pointerScreen) {
        point = {
            x: Number(pointerScreen[0] || 0),
            y: Number(pointerScreen[1] || 0),
        };
    }

    if ((!Number.isFinite(point.x) || !Number.isFinite(point.y))) {
        const cursorPos = getCursorPosition();
        if (cursorPos) {
            point = { x: cursorPos[0], y: cursorPos[1] };
        }
    }

    const dtMs = Math.max(1, now - (runtimeStats.pointer.lastTs || now));
    const dx = point.x - runtimeStats.pointer.x;
    const dy = point.y - runtimeStats.pointer.y;
    const vx = dx / (dtMs / 1000);
    const vy = dy / (dtMs / 1000);
    const speed = Math.hypot(vx, vy);

    runtimeStats.pointer = {
        x: point.x,
        y: point.y,
        vx,
        vy,
        speed,
        lastTs: now,
    };

    const aimOffset = framePayload?.aim_offset || [0, 0];
    const offsetMagnitude = Math.hypot(Number(aimOffset[0] || 0), Number(aimOffset[1] || 0));
    if (offsetMagnitude > 140 && lastOffsetSpikeTs === null) {
        lastOffsetSpikeTs = now;
    }
    if (offsetMagnitude < 40 && lastOffsetSpikeTs !== null) {
        lastRecoveredReactionMs = now - lastOffsetSpikeTs;
        lastOffsetSpikeTs = null;
    }

    return {
        x: Number(point.x.toFixed(2)),
        y: Number(point.y.toFixed(2)),
        dx: Number(dx.toFixed(2)),
        dy: Number(dy.toFixed(2)),
        vx: Number(vx.toFixed(2)),
        vy: Number(vy.toFixed(2)),
        speed: Number(speed.toFixed(2)),
        reactionMs: lastRecoveredReactionMs,
    };
}

function routeDetectorPayload(payload, rawLine) {
    runtimeStats.jsonFrames += 1;
    sendToRenderer('assistant-output', {
        parsed: true,
        type: payload?.type || 'unknown',
        raw: rawLine,
    });

    if (payload?.type === 'detection') {
        runtimeStats.detectionFrames += 1;
        runtimeStats.assistantOnline = true;
        runtimeStats.lastDetectionSource = String(payload.source || '');
        if (runtimeStats.lastDetectionSource && runtimeStats.lastDetectionSource !== 'synthetic') {
            runtimeStats.captureReady = true;
        }
        const normalizedPayload = normalizeDetectionPayload(payload);
        const nodePointer = buildNodePointerTelemetry(normalizedPayload);
        const enrichedFrame = {
            ...normalizedPayload,
            node_pointer: nodePointer,
            settings: { ...runtimeSettings },
            diagnostics: getDiagnosticsSnapshot(),
        };
        sendToRenderer('assistant-frame', enrichedFrame);
        emitChecklistStatus();
        return;
    }

    if (payload?.type === 'status') {
        processStatusPayload(payload);
        sendToRenderer('assistant-status', {
            ...payload,
            diagnostics: getDiagnosticsSnapshot(),
        });
        emitChecklistStatus();
        return;
    }

    safeLog({ event: 'assistant-unknown-payload', payload });
    sendToRenderer('assistant-log', rawLine);
}

function wireAssistantStdout(processRef) {
    let stdoutLineNumber = 0;
    processRef.stdout.on('data', (data) => {
        stdoutBuffer += data.toString();
        const lines = stdoutBuffer.split(/\r?\n/);
        stdoutBuffer = lines.pop() || '';

        for (const line of lines) {
            stdoutLineNumber += 1;
            const trimmed = line.trim();
            if (!trimmed) {
                continue;
            }

            safeLog({ event: 'assistant-stdout-raw', raw: trimmed });
            try {
                const payload = JSON.parse(trimmed);
                routeDetectorPayload(payload, trimmed);
            } catch (error) {
                runtimeStats.parseErrors += 1;
                const errorMessage = `Detector JSON parse failed at stdout line ${stdoutLineNumber}: ${String(error)} | raw=${trimmed.slice(0, 500)}`;
                safeLog({
                    event: 'assistant-json-parse-failed',
                    stdoutLineNumber,
                    error: String(error),
                    raw: trimmed,
                });
                sendToRenderer('assistant-output', {
                    parsed: false,
                    type: 'raw',
                    raw: trimmed,
                    error: String(error),
                    stdoutLineNumber,
                });
                sendToRenderer('assistant-error', errorMessage);
            }
        }
    });
}

function startAssistant() {
    if (assistantProcess) {
        sendToRenderer('assistant-status', { type: 'status', message: 'Assistant already running.' });
        return;
    }

    stdoutBuffer = '';
    runtimeStats.launchedAt = Date.now();
    runtimeStats.jsonFrames = 0;
    runtimeStats.detectionFrames = 0;
    runtimeStats.statusFrames = 0;
    runtimeStats.parseErrors = 0;
    runtimeStats.ipcFrameSends = 0;
    runtimeStats.ipcStatusSends = 0;
    runtimeStats.lastStatusMessage = '';
    runtimeStats.lastDetectionSource = '';
    runtimeStats.yoloLoaded = false;
    runtimeStats.captureReady = false;
    runtimeStats.assistantOnline = false;
    lastOffsetSpikeTs = null;
    lastRecoveredReactionMs = null;
    lastChecklistText = '';

    const launch = getDetectorLaunchConfig();
    if (!launch.command || (!launch.useBinary && !launch.scriptPath)) {
        const msg = 'Detector launch configuration invalid: missing executable or script path.';
        safeLog({ event: 'assistant-launch-invalid', launch });
        sendToRenderer('assistant-error', msg);
        sendToRenderer('assistant-status', { type: 'status', message: msg });
        return;
    }

    safeLog({ event: 'assistant-start', launch });
    sendToRenderer('assistant-status', {
        type: 'status',
        message: `Launching detector: ${launch.command}`,
        diagnostics: getDiagnosticsSnapshot(),
    });

    assistantProcess = spawn(launch.command, launch.args, {
        cwd: launch.appRoot,
        windowsHide: true,
    });

    wireAssistantStdout(assistantProcess);

    assistantProcess.stderr.on('data', (data) => {
        const errorText = data.toString();
        safeLog({ event: 'assistant-stderr', errorText });
        sendToRenderer('assistant-error', errorText);
        sendToRenderer('assistant-status', {
            type: 'status',
            message: `Detector stderr: ${errorText.slice(0, 300)}`,
            diagnostics: getDiagnosticsSnapshot(),
        });
    });

    assistantProcess.on('error', (error) => {
        safeLog({ event: 'assistant-process-error', error: String(error) });
        sendToRenderer('assistant-error', error.message || String(error));
        sendToRenderer('assistant-status', {
            type: 'status',
            message: `Detector failed to start: ${error.message || String(error)}`,
        });
        assistantProcess = null;
        emitChecklistStatus();
    });

    assistantProcess.on('exit', (code, signal) => {
        safeLog({ event: 'assistant-exit', code, signal, stats: getDiagnosticsSnapshot() });
        sendToRenderer('assistant-stopped', { code, signal, diagnostics: getDiagnosticsSnapshot() });
        sendToRenderer('assistant-status', {
            type: 'status',
            message: `Detector stopped (code=${code}, signal=${signal})`,
            diagnostics: getDiagnosticsSnapshot(),
        });
        assistantProcess = null;
        runtimeStats.assistantOnline = false;
        emitChecklistStatus();
    });

    sendToRenderer('assistant-started', { diagnostics: getDiagnosticsSnapshot() });
    emitChecklistStatus();
}

function stopAssistant() {
    if (!assistantProcess) {
        sendToRenderer('assistant-status', { type: 'status', message: 'Assistant is not running.' });
        return;
    }

    sendToRenderer('assistant-status', { type: 'status', message: 'Detector stopping...' });
    try {
        assistantProcess.kill();
    } catch (error) {
        safeLog({ event: 'assistant-stop-failed', error: String(error) });
        sendToRenderer('assistant-error', `Failed to stop detector: ${String(error)}`);
    }
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 1100,
        height: 780,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            nodeIntegration: false,
            contextIsolation: true,
        },
    });

    mainWindow.loadFile(path.join(__dirname, 'ui', 'index.html'));
    if (!app.isPackaged) {
        mainWindow.webContents.openDevTools({ mode: 'detach' });
    }

    mainWindow.on('closed', () => {
        mainWindow = null;
    });
}

app.whenReady().then(() => {
    getLogPath();
    safeLog({ event: 'app-ready' });
    initRobotJs();
    createWindow();

    app.on('activate', () => {
        if (BrowserWindow.getAllWindows().length === 0) {
            createWindow();
        }
    });
});

app.on('window-all-closed', () => {
    stopAssistant();
    if (process.platform !== 'darwin') {
        app.quit();
    }
});

ipcMain.on('toggle-assistant', (_, isRunning) => {
    safeLog({ event: 'ipc-toggle-assistant', isRunning });
    if (isRunning) {
        startAssistant();
    } else {
        stopAssistant();
    }
});

ipcMain.on('update-settings', (_, settings) => {
    safeLog({ event: 'ipc-update-settings', settings });
    if (settings && typeof settings === 'object') {
        runtimeSettings.confidenceThreshold = Number.isFinite(Number(settings.confidenceThreshold))
            ? Number(settings.confidenceThreshold)
            : runtimeSettings.confidenceThreshold;
        runtimeSettings.overlayEnabled = typeof settings.overlayEnabled === 'boolean'
            ? settings.overlayEnabled
            : runtimeSettings.overlayEnabled;
        runtimeSettings.smoothing = Number.isFinite(Number(settings.smoothing))
            ? Number(settings.smoothing)
            : runtimeSettings.smoothing;
        runtimeSettings.predictionSmoothness = Number.isFinite(Number(settings.predictionSmoothness))
            ? Number(settings.predictionSmoothness)
            : runtimeSettings.predictionSmoothness;
        runtimeSettings.boxColor = typeof settings.boxColor === 'string'
            ? settings.boxColor
            : runtimeSettings.boxColor;
        runtimeSettings.boxThickness = Number.isFinite(Number(settings.boxThickness))
            ? Number(settings.boxThickness)
            : runtimeSettings.boxThickness;
        runtimeSettings.boxOpacity = Number.isFinite(Number(settings.boxOpacity))
            ? Number(settings.boxOpacity)
            : runtimeSettings.boxOpacity;
        runtimeSettings.boxGlow = typeof settings.boxGlow === 'boolean'
            ? settings.boxGlow
            : runtimeSettings.boxGlow;
        runtimeSettings.trailColor = typeof settings.trailColor === 'string'
            ? settings.trailColor
            : runtimeSettings.trailColor;
        runtimeSettings.trailLength = Number.isFinite(Number(settings.trailLength))
            ? Number(settings.trailLength)
            : runtimeSettings.trailLength;
        runtimeSettings.trailOpacity = Number.isFinite(Number(settings.trailOpacity))
            ? Number(settings.trailOpacity)
            : runtimeSettings.trailOpacity;
        runtimeSettings.trailThickness = Number.isFinite(Number(settings.trailThickness))
            ? Number(settings.trailThickness)
            : runtimeSettings.trailThickness;
        runtimeSettings.predictionStrength = Number.isFinite(Number(settings.predictionStrength))
            ? Number(settings.predictionStrength)
            : runtimeSettings.predictionStrength;
        runtimeSettings.maxTargets = Number.isFinite(Number(settings.maxTargets))
            ? Math.max(1, Number(settings.maxTargets))
            : runtimeSettings.maxTargets;
        runtimeSettings.showLabels = typeof settings.showLabels === 'boolean'
            ? settings.showLabels
            : runtimeSettings.showLabels;
        runtimeSettings.showIndicators = typeof settings.showIndicators === 'boolean'
            ? settings.showIndicators
            : runtimeSettings.showIndicators;
        runtimeSettings.fontSize = Number.isFinite(Number(settings.fontSize))
            ? Number(settings.fontSize)
            : runtimeSettings.fontSize;
        runtimeSettings.showFPS = typeof settings.showFPS === 'boolean'
            ? settings.showFPS
            : runtimeSettings.showFPS;
        runtimeSettings.overlayTransparency = Number.isFinite(Number(settings.overlayTransparency))
            ? Number(settings.overlayTransparency)
            : runtimeSettings.overlayTransparency;
        runtimeSettings.velocitySensitivity = Number.isFinite(Number(settings.velocitySensitivity))
            ? Number(settings.velocitySensitivity)
            : runtimeSettings.velocitySensitivity;
        runtimeSettings.lockDuration = Number.isFinite(Number(settings.lockDuration))
            ? Number(settings.lockDuration)
            : runtimeSettings.lockDuration;
        runtimeSettings.detectionSensitivity = Number.isFinite(Number(settings.detectionSensitivity))
            ? Number(settings.detectionSensitivity)
            : runtimeSettings.detectionSensitivity;
    }
    sendToRenderer('settings-applied', { ...runtimeSettings });
    sendToRenderer('assistant-status', {
        type: 'status',
        message: `Settings applied: confidence=${runtimeSettings.confidenceThreshold.toFixed(2)} trail=${runtimeSettings.trailLength} prediction=${runtimeSettings.predictionStrength.toFixed(2)}`,
        diagnostics: getDiagnosticsSnapshot(),
    });
});

ipcMain.on('renderer-ready', (_, payload) => {
    runtimeStats.rendererConnected = true;
    safeLog({ event: 'renderer-ready', payload });
    emitChecklistStatus();
});

ipcMain.on('overlay-ready', (_, payload) => {
    runtimeStats.overlayReady = true;
    safeLog({ event: 'overlay-ready', payload });
    emitChecklistStatus();
});

